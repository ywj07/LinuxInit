#!/bin/bash

# by yeweijie
# 2017-08-10


#  修改集群root用户密码
# echo "Hantele@1234!" | passwd --stdin root


CLUSTER=hadoop

/usr/bin/ansible ${CLUSTER} -m shell  -a "echo "Hantele@1234!" | passwd --stdin root"


